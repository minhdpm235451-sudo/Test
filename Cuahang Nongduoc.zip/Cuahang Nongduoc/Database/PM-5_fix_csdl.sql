-- PM-5 / PM-6: bổ sung khóa ngoại còn thiếu cho cuahang.mdb (Access / Jet 4.0)
-- Cách chạy: mở Database\cuahang.mdb bằng Access > Create > Query Design > SQL View,
-- chạy TỪNG câu một (Jet chỉ cho một câu lệnh mỗi lần). Nên sao lưu file trước.
-- Đã kiểm tra dữ liệu hiện tại: không có dòng "mồ côi", nên các câu dưới đều chạy được.
-- Dùng khóa ngoại thường (không CASCADE) để không vô tình xóa dây chuyền dữ liệu.

ALTER TABLE SAN_PHAM          ADD CONSTRAINT FK_SAN_PHAM_DON_VI_TINH    FOREIGN KEY (ID_DON_VI_TINH)  REFERENCES DON_VI_TINH (ID);
ALTER TABLE PHIEU_BAN         ADD CONSTRAINT FK_PHIEU_BAN_KHACH_HANG    FOREIGN KEY (ID_KHACH_HANG)   REFERENCES KHACH_HANG (ID);
ALTER TABLE PHIEU_NHAP        ADD CONSTRAINT FK_PHIEU_NHAP_NHA_CUNG_CAP FOREIGN KEY (ID_NHA_CUNG_CAP) REFERENCES NHA_CUNG_CAP (ID);
ALTER TABLE CHI_TIET_PHIEU_BAN ADD CONSTRAINT FK_CTPB_MA_SAN_PHAM       FOREIGN KEY (ID_MA_SAN_PHAM)  REFERENCES MA_SAN_PHAM (ID);
ALTER TABLE PHIEU_CHI         ADD CONSTRAINT FK_PHIEU_CHI_LY_DO_CHI     FOREIGN KEY (ID_LY_DO_CHI)    REFERENCES LY_DO_CHI (ID);

-- TÙY CHỌN: bảng DAI_LY đang trống, không liên kết bảng nào và code không dùng tới
-- (form Đại lý đang lưu vào KHACH_HANG với LOAI_KH = TRUE). Nếu cả nhóm đồng ý thì bỏ comment để xóa:
-- DROP TABLE DAI_LY;
